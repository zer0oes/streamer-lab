let totalMessages = 0, messagesLimit = 0, noname = "show", nickColor = "user", removeSelector, addition, customNickColor, channelName, provider, highlight;
let animationIn = 'bounceIn';
let animationOut = 'bounceOut';
let hideAfter = 60;
let hideCommands = "no";
let ignoredUsers = [];
let previousSender='';
let emotes = [];
let fieldData;

window.addEventListener('onEventReceived', async function (obj) {
    if (obj.detail.event.listener === 'widget-button') {

        if (obj.detail.event.field === 'testMessage') {
            let emulated = new CustomEvent("onEventReceived", {
                detail: {
                    listener: "message", event: {
                        service: "twitch",
                        data: {
                            time: Date.now(),
                            tags: {
                                "badge-info": "",
                                badges: "moderator/1,partner/1",
                                color: "#5B99FF",
                                "display-name": "StreamElements",
                                emotes: "25:46-50",
                                flags: "",
                                id: "43285909-412c-4eee-b80d-89f72ba53142",
                                mod: "1",
                                "room-id": "85827806",
                                subscriber: "0",
                                "tmi-sent-ts": "1579444549265",
                                turbo: "0",
                                "user-id": "100135110",
                                "user-type": "mod"
                            },
                            nick: channelName,
                            userId: "100135110",
                            displayName: channelName,
                            displayColor: "#5B99FF",
                            badges: [{
                                type: "moderator",
                                version: "1",
                                url: "https://static-cdn.jtvnw.net/badges/v1/3267646d-33f0-4b17-b3df-f923a41db1d0/3",
                                description: "Moderator"
                            }, {
                                type: "partner",
                                version: "1",
                                url: "https://static-cdn.jtvnw.net/badges/v1/d12a2e27-16f6-41d0-ab77-b780518f00a3/3",
                                description: "Verified"
                            }],
                            channel: channelName,
                            text: "Howdy! My name is MrBoost and I am here to serve Kappa",
                            isAction: !1,
                            emotes: [{
                                type: "twitch",
                                name: "Kappa",
                                id: "25",
                                gif: !1,
                                urls: {
                                    1: "https://static-cdn.jtvnw.net/emoticons/v1/25/1.0",
                                    2: "https://static-cdn.jtvnw.net/emoticons/v1/25/1.0",
                                    4: "https://static-cdn.jtvnw.net/emoticons/v1/25/3.0"
                                },
                                start: 46,
                                end: 50
                            }],
                            msgId: "43285909-412c-4eee-b80d-89f72ba53142"
                        },
                        renderedText: 'Howdy! My name is Bill and I am here to serve <img src="https://static-cdn.jtvnw.net/emoticons/v1/25/1.0" srcset="https://static-cdn.jtvnw.net/emoticons/v1/25/1.0 1x, https://static-cdn.jtvnw.net/emoticons/v1/25/1.0 2x, https://static-cdn.jtvnw.net/emoticons/v1/25/3.0 4x" title="Kappa" class="emote">'
                    }
                }
            });
            window.dispatchEvent(emulated);
        }
        return;
    }
  
  if (typeof obj.detail.event.itemId !== "undefined") {
       obj.detail.listener = "redemption-latest"
   }
   const listener = obj.detail.listener.split("-")[0];
   const event = obj.detail.event;
   event.type = listener;

   const eventTypeMapping = {
    'follower': {
        include: (event) => JSON.parse(fieldData.includeFollowers),
        alertText: 'New Follower',
        alertName: (event) => event.name,
        alertType: "follow"
    },
    'cheer': {
        include: (event) => fieldData.includeCheers !== "no" && fieldData.minCheer <= event.amount,
        alertText: `Bits X${event.amount}`,
        alertName: (event) => event.name,
        alertType: "cheer"
    },
     'tip': {
        include: (event) => fieldData.includeTips !== "no" && fieldData.minTip <= event.amount,
        alertText: `Tip $${event.amount}`,
        alertName: (event) => event.name,
        alertType: "donation"
    },
     'merch-latest': {
        include: true,
        alertText: 'New Merch',
        alertName: (event) => event.event.name,
        alertType: "merch"
    },
    'subscriber': {
        include: (event) => JSON.parse(fieldData.includeSubs),
        check: (event) => {
            if (event.gifted || event.bulkGifted) {
                if (event.isCommunityGift && !event.bulkGifted) return false;
                return true;
            }
            return true;
        },
        alertText: (event) => {
            if (event.bulkGifted) {
                return `Gifted ${event.amount} Subs`;
            } else if (event.gifted) {
                return `Sub Gift`;
            } else {
                return `Resub X${event.amount}`;
            }
        },
        alertName: (event) => {
            if (event.bulkGifted) {
                return event.sender;
            } else {
                return event.name;
            }
        },
        alertType: (event) => {
            if (event.bulkGifted) {
                return "sub";
            } else {
                return "sub";
            }
        }
    },
   'raid': {
           include: (event) => fieldData.includeRaids !== "no" && fieldData.minRaid <= event.amount,
           alertText: `Raided x${event.amount} Viewers!`,
           alertName: (event) => event.name,
     	   alertType: "follow"
   }
};

	var mapping = eventTypeMapping[event.type] || eventTypeMapping[obj.detail.event.listener];
if (mapping) {
    const specificMapping = mapping;

    const shouldInclude = (typeof specificMapping.include === 'function' ? specificMapping.include(event) : specificMapping.include);
    console.log(`Event Type: ${event.type}`);
    console.log(`Should Include: ${shouldInclude}`);
    
    if (shouldInclude && (!specificMapping.check || specificMapping.check(event))) {
        const alertText = typeof specificMapping.alertText === 'function' 
            ? specificMapping.alertText(event) 
            : specificMapping.alertText;
        const alertName = typeof specificMapping.alertName === 'function' 
            ? specificMapping.alertName(event) 
            : specificMapping.alertName;
        const alertType = typeof specificMapping.alertType === 'function' 
            ? specificMapping.alertType(event) 
            : specificMapping.alertType;
      
        updateEvent({ alertText, alertName, alertType });
    }
}
  
    if (obj.detail.listener === "delete-message") {
        const msgId = obj.detail.event.msgId;
        $(`.message-row[data-msgid=${msgId}]`).remove();
        return;
    } else if (obj.detail.listener === "delete-messages") {
        const sender = obj.detail.event.userId;
        $(`.message-row[data-sender=${sender}]`).remove();
        return;
    }

    if (obj.detail.listener !== "message") return;
    let data = obj.detail.event.data;
    if (data.text.startsWith("!") && hideCommands === "yes") return;
    if (ignoredUsers.indexOf(data.nick) !== -1) return;
    let message = attachEmotes(data);
    const badgeList = Array.isArray(data.badges) ? data.badges : [];
    let badges = "", badge;
    for (let i = 0; i < badgeList.length; i++) {
        badge = badgeList[i];
        const badgeType = String(badge.type || "badge").replace(/[^a-z0-9_-]/gi, "");
        badges += `<img alt="${badge.description || badgeType}" src="${badge.url}" class="badge badge--${badgeType}"> `;
    }
    let username = data.displayName;
	const color = data.displayColor !== "" ? data.displayColor : "#fff";
    addEvent(username, badges, message, data.isAction, color, getRoleClass(badgeList));
});

window.addEventListener('onWidgetLoad', function (obj) {
    fieldData = obj.detail.fieldData;
    animationIn = fieldData.animationIn;
    animationOut = fieldData.animationOut;
    hideAfter = fieldData.hideAfter;
    messagesLimit = fieldData.messagesLimit;
    nickColor = fieldData.nickColor;
    customNickColor = fieldData.customNickColor;
    hideCommands = fieldData.hideCommands;
    channelName = obj.detail.channel.username;
    animate = fieldData.messageAlign;
    noname = fieldData.noname;
    fetch('https://api.streamelements.com/kappa/v2/channels/' + obj.detail.channel.id + '/').then(response => response.json()).then((profile) => {
        provider = profile.provider;
    });
    ignoredUsers = fieldData.ignoredUsers.toLowerCase().replace(" ", "").split(",");
});

function attachEmotes(message) {
    let text = html_encode(message.text);
    let data = message.emotes;
    return text
        .replace(
            /([^\s]*)/gi,
            function (m, key) {
                let result = data.filter(emote => {
                    return emote.name === key
                });
                if (typeof result[0] !== "undefined") {
                    let url = result[0]['urls'][1];
                    return `<div class="emote"><img alt="" src="${url}"/></img></div>`;
                } else return key;

            }
        );
}

function html_encode(e) {
    return e.replace(/[<>"^]/g, function (e) {
        return "&#" + e.charCodeAt(0) + ";";
    });
}
function getRoleClass(badges) {
    const types = new Set(badges.map((badge) => badge.type));
    if (types.has("broadcaster")) return "role-streamer";
    if (types.has("moderator")) return "role-moderator";
    if (types.has("vip")) return "role-vip";
    if (types.has("artist-badge")) return "role-artist";
    return "role-viewer";
}

function addEvent(username, badges, message, isAction, color, roleClass = "role-viewer") {
    totalMessages += 1;
    let actionClass = "";
    if (isAction) {
        actionClass = "action";
    }

 const chatContainer = document.getElementById('log');
    const chatTemplate = document.getElementById('chatlist_item').innerHTML;
    const badgesHTML = badges;
    const randomUser = username;
    const randomColor = color;
    const randomMessage = message;
    const newMessage = chatTemplate.replace(/{from}/g, randomUser).replace(/{color}/g, randomColor).replace(/{roleClass}/g, roleClass).replace('<span class="badges"></span>', `<span class="badges">${badgesHTML}</span>`).replace('{separator}', ':').replace('{message}', randomMessage);
    chatContainer.insertAdjacentHTML('beforeend', newMessage);
}

 function updateEvent(alertData) {
     const eventContainer = document.getElementById('log');
     const eventTemplate = document.getElementById('eventlist_item').innerHTML;

     const newEvent = eventTemplate
         .replace(/{from}/g, alertData.alertName)
         .replace(/{color}/g, alertData.alertColor)
         .replace(/{type}/g, alertData.alertType)
         .replace('{eventMessage}', alertData.alertText);
 
     eventContainer.insertAdjacentHTML('beforeend', newEvent);
 }

(async () => {
    const chatLog = document.querySelector("#log");
    
    document.addEventListener("onLoad", onGoalLoad);
    document.addEventListener("onEventReceived", onGoalEvent);
    
      function onGoalLoad(e) {
    }
    
        function onGoalEvent(e) {
        console.log(e)
    }

    const config = {
        horizontal: {horizontal},
        smooth_scroll: true,
        smooth_scroll_duration: 0.6,
        flipX: {flipX},
        flipY: {flipY},
        showTone: {showTone},
        exclamation: "{exclamation}",
        questionmark: "{questionmark}",
        mixedmark: "{mixedmarks}",
        MESSAGE_THRESHOLD: 5, // no user options below this config
        TIME_INTERVAL: 2 * 1000,
        FAST_MODE_DURATION: 3 * 100,
        movementX: 0,
        movementY: "+=10",
        MESSAGE_REMOVE_DURATION: {hideAfter} * 1000
    };
    
    if(config.horizontal){
      config.movementX = "-=10";
      config.movementY = 0;
      document.getElementById('log').classList.add('horizontal');
    }

    let messageCounter = 0;
    let lastMessageTimestamp = Date.now();
    let isFastMode = false;

    await NerdLoader.load(["https://cdnjs.cloudflare.com/ajax/libs/gsap/3.5.0/gsap.min.js"]);

    const adjustAnimationSpeed = () => gsap.globalTimeline.timeScale(isFastMode ? 8 : 1);
  
    function nodeInDocument(node) {
        while (node) {
            if (node === document) {
                return true;
            }
            node = node.parentNode;
        }
        return false;
    }
  
    function adjustScrollDuration() {
        config.smooth_scroll_duration = isFastMode ? 0 : 0.8;
    }

    function resetFastMode() {
        isFastMode = false;
        adjustAnimationSpeed();
        adjustScrollDuration(); 
    }

    let fastModeTimeout;

    function checkMessageRate() {
        const currentTime = performance.now();
        const newFastMode = currentTime - lastMessageTimestamp < config.TIME_INTERVAL && messageCounter > config.MESSAGE_THRESHOLD;

        if (newFastMode && !isFastMode) {
            isFastMode = true;
            adjustScrollDuration();
            adjustAnimationSpeed();
          
            clearTimeout(fastModeTimeout);
            fastModeTimeout = setTimeout(resetFastMode, config.FAST_MODE_DURATION);
        }
    }
  
    function setFlipConfigurations() {
        const flipConfigurations = {
            rotateX: config.flipY ? "180deg" : "0deg",
            rotateY: config.flipX ? "180deg" : "0deg",
            top: config.flipY ? 0 : 'auto',
            right: config.flipX ? 0 : 'auto',
            left: config.flipX ? 'auto' : 'auto'
        };
        if (config.flipX) {
          chatLog.classList.add('flippedX');
        } else {
          chatLog.classList.add('notFlippedX');
        }
        if (config.flipY) {
            chatLog.classList.add('flippedY');
        }
        gsap.set("#log", flipConfigurations);
    }
  
    function handleSmoothScroll(animatedElements) {
        let totalCombinedWidth = 0;
        let totalCombinedHeight = 0;
        const verticalSpacing = parseFloat(getComputedStyle(chatLog).getPropertyValue('--spacing')) || 0;

        animatedElements.forEach((element,i) => {
            const { width, height, marginRight } = getComputedStyle(element);
            totalCombinedWidth += parseFloat(width) + parseFloat(marginRight);
            totalCombinedHeight += parseFloat(height) + (i === 0 ? 0 : verticalSpacing);

            const scrollProps = {
                x: config.horizontal ? `${totalCombinedWidth - parseFloat(width)}px` : "+=0",
                y: config.horizontal ? "+=0" : `-${totalCombinedHeight - parseFloat(height)}px`,
                duration: config.smooth_scroll ? config.smooth_scroll_duration : 0
            };

            gsap.to(element, scrollProps);
        });
    }
  
function shouldAddBigEmotesClass(element) {
        let containsText = false;
        let containsValidNodes = false;

        for (let node of element.childNodes) {
            if (node.nodeType === Node.TEXT_NODE && node.nodeValue.trim() !== "") {
                containsText = true;
            } else if (node.nodeType === Node.ELEMENT_NODE) {
                if (node.classList.contains('emote')) {
                    containsValidNodes = true;
                } else {
                    return false;
                }
            }
        }

        return containsValidNodes && !containsText;
    }

    function updateEmoteSizes(element) {
        if (element.classList.contains('bigEmotes')) {
            const emoteElements = element.querySelectorAll('.emote');
            emoteElements.forEach(emote => {
                const styleAttr = emote.getAttribute('style');
                if (styleAttr) {
                    const newStyleAttr = styleAttr.replace(/1\.0/g, '3.0');
                    emote.setAttribute('style', newStyleAttr);
                }
    
                const imgElement = emote.querySelector('img');
                if (imgElement) {
                    const srcAttr = imgElement.getAttribute('src');
                    if (srcAttr) {
                        const newSrcAttr = srcAttr.replace(/1\.0/g, '3.0');
                        imgElement.setAttribute('src', newSrcAttr);
                    }
                }
            });
        }
    }
  
    function createAnimation(element) {
  
        if (element.getAttribute("animated") || !nodeInDocument(element)) return;
      
        let messageElement = element.querySelector('.message');
        if (messageElement && shouldAddBigEmotesClass(messageElement) && {horizontal} !== true) {
            messageElement.classList.add('bigEmotes');
            updateEmoteSizes(messageElement);
        }
  
        adjustAnimationSpeed();
      
        gsap.utils.toArray('.chatElement:not([animated])').forEach(element => {
            if (nodeInDocument(element)) {  
                element.setAttribute('animated', 'true');
            }
        });
  
        // Handle smooth scrolling
        const animatedElements = gsap.utils.toArray('.chatElement[animated]').reverse();
        handleSmoothScroll(animatedElements);
  
        const activeElement = document.querySelector('.chatElement[animated]:last-of-type');
        animateActiveElement(activeElement);
  
        messageCounter++;
        checkMessageRate();
        lastMessageTimestamp = Date.now();

        if ({hideAfter} !== 999) {
          const timer = setTimeout(() => {
              if (nodeInDocument(element)) {
                  // Fade out the element before removing it
                  gsap.to(element, {
                      opacity: 0,
                      duration: 0.5,
                      onComplete: () => {
                          element.remove();
                      }
                  });
              }
          }, config.MESSAGE_REMOVE_DURATION);
  
          element.setAttribute('data-timer', timer);
    }
  }
  
    function checkMessageType(element) {
      if (!element) return;
      let messageContainer = element.querySelector('.message');
      if (!messageContainer) return;

      let text = messageContainer.textContent || messageContainer.innerText;
      text = text.trim();

      let tone, imageURL;

      switch (text.slice(-2)) {
        case '!?':
        case '?!':
          tone = 'mixed';
          imageURL = config.mixedmark;
          break;
        default:
          let lastChar = text.slice(-1);
          if (lastChar === '?') {
            tone = 'question';
            imageURL = config.questionmark
          } else if (lastChar === '!') {
            tone = 'exclamation';
            imageURL = config.exclamation;
          }
      }


      if (tone) {
        updateElementWithTone(element, tone, imageURL);
      }
    }

function updateElementWithTone(element, tone, imageURL) {
  element.classList.add('showTone');

  let toneDiv = element.querySelector('.tone');
  if (!toneDiv) {
    toneDiv = document.createElement('div');
    toneDiv.className = 'tone';
    element.appendChild(toneDiv);
  }

  let toneImage = document.createElement('img');
  toneImage.src = imageURL;
  toneImage.alt = tone + ' tone';

  toneDiv.appendChild(toneImage);

}

    function animateActiveElement(element) {
        if (!element) return;
        if (config.showTone) checkMessageType(element);
        gsap.set(element.querySelectorAll(".tone img"), {rotation: gsap.utils.random(-10, 10)});
      
        let message = element.querySelector('.message');

        const timeline = gsap.timeline();

        if (element.classList.contains("chatMsg")) {
            timeline
                .set(element, { autoAlpha: 1 })
                .from(element.querySelectorAll(".topline"), { opacity: 0, x:config.movementX, y: config.movementY, duration: 0.6, ease: "power3.in" })
                .from(element.querySelector(".chatBg"), { opacity: 0, x:config.movementX, y: config.movementY, duration: 0.6, ease: "power3.in" }, "-=0.3")
                .from(element.querySelector(".message"), {opacity: 0, duration: 0.3})
                .from(element.querySelector(".tone"), {opacity: 0, rotation: gsap.utils.random(30, 70), scale: 1.4, duration: 0.8, ease: "back.out(2.5)"}, "-=0.2")
        } else if (element.classList.contains("chatEvent")) {
          
          let eventMsg = element.querySelector('.eventMessage');
          
            timeline
                .set(element, { autoAlpha: 1 }, 0.4)
                .from(element.querySelector(".eventBg"), { width: 0, duration: 0.6, ease: "power3.in" })
                .from(element.querySelector(".innerEvent"), {opacity: 0, duration: 0.3})

        }

        offScreenObserver.observe(element);
    }
    
    function setupMessageRateResetInterval() {
        setInterval(() => {
            if (!isFastMode) {
                messageCounter = 0;
            }
        }, config.TIME_INTERVAL);
    }
  
    function setupObserver() {
        const observer = new MutationObserver(mutationsList => {
            mutationsList.forEach(mutation => {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach(node => {
                        if (node.nodeType === 1 && (node.classList.contains('chatMsg') || node.classList.contains('chatEvent'))) {
                            gsap.killTweensOf(node);
                            createAnimation(node);
                        }
                    });
                }
            });
        });
        observer.observe(chatLog, { childList: true, subtree: true, attributes: false, characterData: false });
    }

    let offScreenObserver;

    function setupOffScreenObserver() {
        offScreenObserver = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (!entry.isIntersecting && nodeInDocument(entry.target)) {
                    entry.target.remove();
                    offScreenObserver.unobserve(entry.target);
                }
            });
        }, {
            root: null,
            rootMargin: '0px',
            threshold: 0
        });
    }

    setFlipConfigurations();
    setupMessageRateResetInterval();
    setupObserver();
    setupOffScreenObserver();
  
    Array.from(chatLog.children).forEach(child => {
        if (child.classList.contains('chatMsg') || child.classList.contains('chatEvent')) {
            createAnimation(child);
        }
    });
})();
